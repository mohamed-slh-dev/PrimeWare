@extends('layouts.supplier')


@section('content')



{{-- continue header --}}
<!-- start page title -->
<div class="page-title-box">
    <div class="container-fluid">
        <div class="page-title-content">
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <h4>Home</h4>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end page title -->

</header>

{{-- endheader --}}




{{-- content --}}
<div class="main-content">
    <div class="page-content">


        <div class="container-fluid">

            
            {{-- boxes row --}}
            <div class="row">
                <div class="col">
                    <div class="card text-center">
                        <div class="mb-2 card-body text-muted">
                            <h3 class="text-info mt-2">{{ $analytics['dispatchedCount'] }}</h3>
                            Total Products<br>Dispatched
                        </div>
                    </div>
                </div>
            
            
            
                <div class="col">
                    <div class="card text-center">
                        <div class="mb-2 card-body text-muted">
                            <h3 class="text-info mt-2">{{ $analytics['receivedCount'] }}</h3>
                            Total Products<br>Received
                        </div>
                    </div>
                </div>
            
            
                <div class="col">
                    <div class="card text-center">
                        <div class="mb-2 card-body text-muted">
                            <h3 class="text-info mt-2">{{ $analytics['availableCount'] }}</h3>
                            Total Products<br>in Stock
                        </div>
                    </div>
                </div>
            
            
                <div class="col">
                    <div class="card text-center">
                        <div class="mb-2 card-body text-muted">
                            <h3 class="text-success mt-2">{{ $analytics['soldCount'] }}</h3>
                            Total Products<br>Sold
                        </div>
                    </div>
                </div>
            
            
                <div class="col">
                    <div class="card text-center">
                        <div class="mb-2 card-body text-muted">
                            <h3 class="text-success mt-2">{{ $analytics['cashCollection'] }}</h3>
                            Cash<br>Collection
                        </div>
                    </div>
                </div>

            
            
            </div>
            <!-- end boxes row -->





            {{-- boxes row 2 --}}
            <div class="row">

                
                <div class="col">
                    <div class="card text-center">
                        <div class="mb-2 card-body text-muted">
                            <h3 class="text-info mt-2">-</h3>
                            Number of <br>Deliveries
                        </div>
                    </div>
                </div>
            
            
            
                <div class="col">
                    <div class="card text-center">
                        <div class="mb-2 card-body text-muted">
                            <h3 class="text-info mt-2">-</h3>
                            Total<br>Delivered
                        </div>
                    </div>
                </div>
            
            
                <div class="col">
                    <div class="card text-center">
                        <div class="mb-2 card-body text-muted">
                            <h3 class="text-info mt-2">-</h3>
                            Total Delivery<br>Cost
                        </div>
                    </div>
                </div>
            
            
                <div class="col">
                    <div class="card text-center">
                        <div class="mb-2 card-body text-muted">
                            <h3 class="text-danger mt-2">-</h3>
                            Canceled<br>Deliveries
                        </div>
                    </div>
                </div>
            
            
                <div class="col">
                    <div class="card text-center">
                        <div class="mb-2 card-body text-muted">
                            <h3 class="text-danger mt-2">{{ $analytics['damagedCount'] }}</h3>
                            Damaged<br>Products
                        </div>
                    </div>
                </div>
            
            
            
            </div>
            <!-- end boxes row 2 -->


            {{-- row --}}
            <div class="row">

                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title mb-4">Total Deliveries</h4>

                            <div class="row text-center mt-4">
                                <div class="col-2">
                                    <h5 class="mb-2 font-size-18">0</h5>
                                    <p class="text-muted text-truncate">Delivered</p>
                                </div>
                                <div class="col-8">
                                    <div id="pie-chart" style="height: 300px; margin-top: -60px;"></div>
                                </div>
                                <div class="col-2">
                                    <h5 class="mb-2 font-size-18">0</h5>
                                    <p class="text-muted text-truncate">Returned | Canceled</p>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>

            </div>
            <!-- end row -->



            {{-- all orders --}}
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Deliveries</h4>
                            <p class="card-title-desc">Review all delivery orders</p>

                            <div class="table-responsive">
                                <table class="table mb-0">
                                
                                    <thead class="thead-light">
                                        <tr>
                                            <th>Delivery No.</th>
                                            <th>Reference ID</th>
                                            <th>Customer</th>
                                            <th>Phone</th>
                                
                                            <th>City</th>
                                            <th>District</th>
                                            <th>Address</th>
                                
                                            <th>Location</th>
                                
                                            <th>Delivery Date</th>
                                            <th>Comments/Notes</th>
                                            <th>Status</th>
                                            <th>Received At</th>
                                            <th>Cancel</th>
                                        </tr>
                                    </thead>
                                
                                    {{-- tbody --}}
                                    <tbody>
                                
                                        {{-- table row --}}
                                
                                        <tr>
                                            <td># 1</td>
                                            <td>3211</td>
                                            <td>Osama Yaseen</td>
                                            <td>+971 4 563 112</td>
                                
                                            <td>Dubai</td>
                                            <td>Al Abar</td>
                                
                                            <td>Dubai Kilo St. Block 11</td>
                                
                                            <td><a href="https://www.google.com/maps/search/?api=1&query=" class="text-warning" target="_blank">Show
                                                    Map</a></td>
                                
                                
                                            {{-- deliverydate + delivery time --}}
                                            <td>29-9-2021 9:00 PM</td>
                                
                                            <td>Lorem ipsum dolor sit amet consectetur adipisicing elit.</td>
                                
                                
                                            <td><i class="mdi mdi-checkbox-blank-circle text-warning"></i>Requested</td>
                                
                                            <td>-</td>
                                
                                
                                
                                
                                            {{-- cancel delivery --}}
                                            <td class="text-left">
                                                {{-- form (add new partner) --}}
                                                <form action="" method="post">
                                
                                                    {{-- method fields (was post) --}}
                                                    @method('GET')
                                                    @csrf
                                
                                
                                                    <button type="submit" class="custom-edit-button">
                                                        <i class="fas fa-trash-alt text-danger"></i>
                                                    </button>
                                
                                
                                
                                                    <input type="hidden" name="orderid" value="1">
                                
                                                </form>
                                            </td>
                                
                                
                                        </tr>
                                        {{-- end table row --}}
                                
                                
                                    </tbody>
                                    {{-- end tbody --}}
                                </table>
                            </div>
                            {{-- end of table wrapper --}}

                            {{-- paginations --}}
                            <div class="pagination mt-4">
                              
                            </div>
                            {{-- end paginations --}}

                        </div>
                    </div>
                </div>
                {{-- end column --}}



            </div>
            <!-- end row -->

        </div>
        <!-- container-fluid -->
    </div>
    <!-- End Page-content -->

    {{-- footer --}}
    <footer class="footer">

    </footer>
    {{-- endfooter --}}

</div>
<!-- end main content-->

{{-- endcontent --}}




{{-- modal --}}




{{-- endmodals --}}



@endsection


