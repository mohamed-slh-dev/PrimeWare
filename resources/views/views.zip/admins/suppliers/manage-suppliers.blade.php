@extends('layouts.admin')


@section('content')



{{-- continue header --}}


<!-- start page title -->
<div class="page-title-box">
    <div class="container-fluid">
        <div class="page-title-content">

            {{-- row --}}
            <div class="row align-items-center">

                <div class="col-sm-6">
                    <h4>Manage Suppliers</h4>
                </div>

                <div class="col-sm-6">
                    <div class="float-right d-none d-md-block">

                        {{-- form (search supplier) --}}
                        <form class="app-search" action="" method="post">

                            {{-- method fields (was post)--}}
                            @method('GET')
                            @csrf

                            <input name="searchinput" type="text" class="form-control" placeholder="Supplier Name">
                            <span type="submit" class="fa fa-search"></span>

                        </form>

                    </div>
                </div>
            </div>
            {{-- end row --}}

        </div>
    </div>
</div>
<!-- end page title -->

</header>

{{-- end header --}}







{{-- content --}}


<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            {{-- <p class="card-title-desc">Manage all suppliers Info.</p> --}}

                            <div class="table-responsive">
                                <table class="table mb-0">

                                    <thead class="thead-light">
                                        <tr>
                                            <th>Supplier</th>
                                            <th>E-mail</th>
                                            <th>City</th>
                                            <th>District</th>
                                            <th>Contract Start Date</th>
                                            <th>Contract End Date</th>
                                            <th>Contract</th>
                                            {{-- <th>Info</th> --}}
                                        </tr>
                                    </thead>
                                    <tbody>

                                      {{-- counter for ids --}}
                                      <?php $counter = 1; ?>
                                        
                                      {{-- foreach --}}
                                      @foreach ($suppliers as $supplier)

                                      <tr>
                                          <td>{{ $supplier->name }}</td>
                                          <td>{{ $supplier->portalemail }}</td>
                                          {{-- <td>{{ $supplier->type->name }}</td> --}}

                                          <td>{{ $supplier->city->name }}</td>

                                          <td class="text-success">
                                              <a class="text-success" href="https://www.google.com/maps/search/?api=1&query={{ ltrim($supplier->locationlink, '@') }}">{{ $supplier->district->name }}</a>
                                          </td>
                                          <td>{{ $supplier->startdate }}</td>
                                          <td>{{ $supplier->enddate }}</td>

                                          {{-- download contract --}}
                                          <td> 
                                              <a target="_blank" href="{{ asset('assets/img/suppliers/contracts/'.$supplier->contract) }}">Download</a>
                                          </td>

                                         

                                          {{-- edit --}}
                                          {{-- <td>
                                              {{-- form (add new supplier) --}}
                                              {{-- <form action="{{ route('admin.editothersupplier') }}" method="post" enctype="multipart/form-data"> --}}
                                              
                                                  {{-- method fields --}}
                                                  {{-- @method('POST')
                                                  @csrf

                                                  <button type="submit" class="custom-edit-button">
                                                      <i class="far fa-edit text-primary"></i>
                                                  </button>
                                                  
                                                  <input type="hidden" name="id" value="{{ $supplier->id }}">
                                              </form> --}}
                                          {{-- </td> --}}

                                      </tr>
                                      {{-- end of first cell (repeat) --}}

                                      {{-- increase counter --}}
                                      <?php $counter++; ?>
                                      
                                      @endforeach
                                      {{-- end foreach (repeat) --}}

                                    </tbody>
                                    {{-- end tbody --}}
                                </table>
                            </div>
                            {{-- end table + wrapper --}}

                            {{-- paginations --}}
                            <div class="pagination mt-3">
                                @if($suppliers instanceof \Illuminate\Pagination\LengthAwarePaginator )
                                
                                {{$suppliers->links()}}
                                
                                @endif
                            </div>


                        </div>
                    </div>
                </div>
                <!-- end col -->
            </div>
        </div>
        <!-- container-fluid -->
    </div>
    <!-- End Page-content -->

    <footer class="footer">

    </footer>
</div>
<!-- end main content-->

</div>
<!-- END layout-wrapper -->




{{-- endcontent --}}





@endsection